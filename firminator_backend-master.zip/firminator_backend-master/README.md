#Firminator
The first (afaik) open source (wannabe) firmware vulnerability scanner 

Firminator goal is to provide static & dynamic analysis of firmwares. For the dynamic analysis the firmwares will be emulated using  [firmadyne](https://github.com/firmadyne/firmadyne)




##Contribute
If you want to contribute feel free to ping me on twiter [@MisterCh0c](https://twitter.com/misterch0c) or on [IRC #firminator on Freenode](https://webchat.freenode.net/), there is a dev server,, a Trello board with tasks and another repo for the frontend (AngularJS & Material Design).<br>The requirements for the project are the same as for [firmadyne](https://github.com/firmadyne/firmadyne). <br>This backend is using Django.

##Contributors

[@MisterCh0c](https://twitter.com/misterch0c)

[@GeoffreyVDBerge](https://twitter.com/geoffreyvdberge)

[@G4N4P4T1](https://twitter.com/G4N4P4T1)

[Robin](https://github.com/robin-poncin)
