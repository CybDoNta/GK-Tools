#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "mem_ops.h"

bool blacklist_ip(char * addr);
