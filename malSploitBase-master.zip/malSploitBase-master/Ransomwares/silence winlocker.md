

```
SQL injection.

http://localhost/forma.php?pin=4322 http://localhost/index.php?x=1&act=delete&id=1 http://localhost/picture.php?pin=8787 http://localhost/tmp/get.php?pin=1334
```
