

Kevin Breen - DarkComet From Defense To Offense - Identify your Attacker
[![Kevin Breen - DarkComet From Defense To Offense - Identify your Attacker](http://img.youtube.com/vi/tRM6HrW7BAc/0.jpg)](https://youtu.be/tRM6HrW7BAc "Video Title")

[Slides](https://techanarchy.net/?attachment_id=836)

[POC by Shawn Denbow and Jesse Herts](http://www.matasano.com/research/PEST-CONTROL.pdf)

[Wikipedia](https://en.wikipedia.org/wiki/DarkComet)

#### Vulnerabilities

* Remote file read
* Data base poisoning
* SQL injection

[DarkComet ToolKit](https://github.com/kevthehermit/dc-toolkit)

[DarkComet Metasploit Module](https://github.com/samvartaka/exploits/blob/master/darkcomet_filedownloader.rb)
