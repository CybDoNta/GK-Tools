
[Wikipedia](https://en.wikipedia.org/wiki/Tiny_Banker_Trojan)

```
Type: SQLi

\tinybanker panel\admin/control/logs.act.php http://localhost/logs.act.php Post Data: bot_uid=1&botcomment=mate
POST
```
