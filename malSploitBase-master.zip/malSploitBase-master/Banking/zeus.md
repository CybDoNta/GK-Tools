#### Zeus & Zeus Evo

[Wikipedia](https://en.wikipedia.org/wiki/Zeus_%28malware%29)

```
Type: SQLi

Vuln: http://localhost/gate.php?ip=8.8.8.8
```
