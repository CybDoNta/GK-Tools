
[Wikipedia](https://en.wikipedia.org/wiki/Citadel_%28malware%29)

Type: SQLi
```
Vuln: http://localhost/cp.php?bots=1
```
