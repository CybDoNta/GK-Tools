### Contribute

Feel free to make a pull request on https://github.com/misterch0c/malSploitBase
