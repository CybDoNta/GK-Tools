
```
Type: Stored XSS and iFrame redirect

Click add task Command: IFRAME SRC="whateverekorlemonpartyorwhatnot.com" /IFRAME

Then Click Create Task Finally click Tasks. VOILA!

(Credits to asterea for finding this botnet panel)
```
