
<pre>
Type: SQLi
Vuln: http://localhost:8992/panel/gate.php?botid=1&newbot=1&country=AUD&country_code=AUD &ip=10.0.0.1&os=win&cpu=amd&type=mate&cores=1999&version=88.8&net=wlan&admin=narwals&busy=no&lastseen=now

</pre>
