

```
Type: SQLi

Vuln: http://localhost/delete_command.php?deleteID=1
```
