
```
Type: SQLi

http://localhost/control.php?id=1 http://localhost/guest.php?id=1

POST
```
