
```
SQL injection.

localhost/index.php POSTDATA i=1881&p=80&u=8302&h=282&s=AUD
```
