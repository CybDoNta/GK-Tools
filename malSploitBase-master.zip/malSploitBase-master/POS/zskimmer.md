

```
Type: SQLi

Vuln: http://localhost/process.php?xy=2
```
