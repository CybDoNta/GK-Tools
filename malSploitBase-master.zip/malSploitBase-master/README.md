### [Malware Exploit Database](https://www.pwnmalw.re/)
https://www.pwnmalw.re/


![alt text](http://i.imgur.com/3dYszDH.png)


Made to be used by [Raneto](https://github.com/gilbitron/Raneto).


Feel free to make a PR to add vulnerabilities.
