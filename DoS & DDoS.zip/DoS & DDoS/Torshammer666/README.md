# Tor's hammer
## Written by .?@#]*@