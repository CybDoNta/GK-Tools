#!/usr/bin/python
#
# Lulz Hash Generator
# 
#
# Lulz Security 2016 Team 
# |\||\| && |_|B3R-R007 
# June 2016 
# v0.1

print """
. /$$                 /$$            /$$$$$$                    
.| $$                | $$   2016    /$$__  $$                    
.| $$       /$$   /$$| $$ /$$$$$$$$| $$  \__/  /$$$$$$   /$$$$$$$
.| $$      | $$  | $$| $$|____ /$$/|  $$$$$$  /$$__  $$ /$$_____/
.| $$      | $$  | $$| $$   /$$$$/  \____  $$| $$$$$$$$| $$      
.| $$      | $$  | $$| $$  /$$__/   /$$  \ $$| $$_____/| $$      
.| $$$$$$$$|  $$$$$$/| $$ /$$$$$$$$|  $$$$$$/|  $$$$$$$|  $$$$$$$
.|________/ \______/ |__/|________/ \______/  \_______/ \_______/
 //Special edition 2016  //Laughing at your security since way back\\
------------------------//    Our new Base visit us @ Lulzsec.nl    \\
                         ---------------------------------------------

                            [Tool] 
                         LulzHashGen V0.1     
      
                           Visit us                         
                  + http://www.lulzsec.nl +
          ';..;' Faitfully yours LulzSec 2016 ';..;'
                      + //Tips hats\\ +           
                     + //   + By +  \\ +
                    + //    |\||\|   \\ +
                   + //       &&      \\ +
                  + //   |_|B3R-R007   \\ +
========================================================================
"""


print "[~]Code your freedom "

print""

import re
import hashlib

key_string = raw_input( "Key to turn into an MD5 password? " )

input_str = raw_input("Please provide some info: ")

print "Your input was:", input_str

print hashlib.md5( key_string ).hexdigest()

print""

print "thnx for your use of our tool."
print "Faitfully yours LulzSecurity team 2016 "
print "End Lulz program"
