#!/usr/bin/python
#
# Ludpf.py
# 
#Coded by LulzSecurity2016	
# 

print"""

                _.--| LuLz|:                    
               <____|.----||                    
                      .---''---,                
   The                 ;..__..'    _...         
    Lulz            , '/  ||/..--''    \        
     Boat         ,'_ /'.-||            :       
      2016   _..-' ''/    ||  \    \   _|/|     
           \        /-._;/||   \    \,;'   \    
           ,\      /    /`||    \   //    `:`.  
         ,'  \    /-._;/  ||    : ::    ,.   . 
       ,'     \  /    /`-.||    | || ' :  `.`.)
    _,'        |;._: /|  ;||    | `|   :    `' 
  ,'   `.      /    /`-:_/||    |  |  : \      
  `--.   )    /'-._/    /:||       |   \ \     
     /  /    /'_  /;`-./_;||__..--';    : :    
    /  (    /  -./_  _/  .||'o |   /     ' |    
   /  , \._/_/_./--''/_  /||___|_,'      | |    
  :  /   `'-'--'----'---------'          / |    
  | :     O ._O   O_. O ._O   O_.       ; ;    
  : `.      //    //    //    //       /     
~~~`.______//____//____//____//_______ ,'~~     
          //    //~   //    // ~ ~ ~ ~~~~    
   ~~   _//   _//   _// ~ _//    ~  ~ ~ ~    
 ~     / /   / /   / /   / /  ~      ~~       
      ~~~   ~~~   ~~~   ~~~                   
                                   Setting Sail to the horizon. 
                                              Yours 
                                        lulzSecurity2016
                                           % |\| |\| %
                                             Ludpif.py
"""

#import
import os
import sys
import time
import socket
import random
import Queue
import threading
import multiprocessing
import subprocess

#main 


