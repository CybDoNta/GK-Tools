extract(1) -- Easily extract/uncompress any archives
============================================

## SYNOPSIS

extract [*options*] [--help]<br>

## USAGE
## DESCRIPTION
## OPTIONS

* -h, --help:
    Show usage help.

## EXAMPLES

```fish
extract
```

## SEE ALSO
