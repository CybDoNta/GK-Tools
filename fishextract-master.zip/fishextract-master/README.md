[![Build Status][travis-badge]][travis-link]
[![Slack Room][slack-badge]][slack-link]

# extract

Easily extract/uncompress any archives

## Install

With [Fisherman]

```
fisher i extract
```

## Usage

```fish
extract
```

[travis-link]: https://travis-ci.org/@misterch0c/extract
[travis-badge]: https://img.shields.io/travis/@misterch0c/extract.svg?style=flat-square
[slack-link]: https://fisherman-wharf.herokuapp.com/
[slack-badge]: https://img.shields.io/badge/slack-join%20the%20chat-00B9FF.svg?style=flat-square
[Fisherman]: https://github.com/fisherman/fisherman
