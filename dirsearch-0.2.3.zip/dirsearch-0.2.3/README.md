dirs3arch
=========

Current Release: v0.2.3 (2014-7-7)

Overview
--------
dirs3arch is a simple command line tool designed to brute force directories and files in websites.


Features
--------
- Keep alive connections
- Multithreaded
- Detect not found web pages when 404 not found errors are masked (.htaccess, web.config, etc).
- Recursive brute forcing

Changelog
---------
- 0.2.3 - 2014.7.7 Fixed some bugs, minor refactorings, exclude status switch, "pause/next directory" feature, changed help structure, expaded default dictionary
- 0.2.2 - 2014.7.2 Fixed some bugs, showing percentage of tested paths and added report generation feature
- 0.2.1 - 2014.5.1 Fixed some bugs and added recursive option
- 0.2.0 - 2014.1.31 Initial public release


