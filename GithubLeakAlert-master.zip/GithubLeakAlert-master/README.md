GithubLeakAlert monitor GitHub to find credential associated with an host. Then it creates an issue in the repository to warn it's owner he might have unknowingly published his password.

<p align="center">
  <img src="http://i.imgur.com/Az8ACOM.png" alt="example"/>
</p>
