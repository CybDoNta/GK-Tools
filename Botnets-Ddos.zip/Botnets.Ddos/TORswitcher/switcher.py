from stem import Signal
from stem.control import Controller
import os
import time

num = input('How long to wait: ')

try:
	num = float(num)
except ValueError:
	print('Please enter in a number.\n')

def executeSomething():
	with Controller.from_port(port = 9051) as controller:
		controller.authenticate()
		controller.signal(Signal.NEWNYM)
    	time.sleep(num)

while True:
    executeSomething()