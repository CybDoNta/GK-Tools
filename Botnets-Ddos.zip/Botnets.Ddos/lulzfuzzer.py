#
#LulzFuzzer.py
#
#Build By |\||\
#
#LulzSecurity2016

print"""

                _.--| LuLz|:                    
               <____|.----||                    
                      .---''---,                
   The                 ;..__..'    _...         
    Lulz            , '/  ||/..--''    \        
     Boat         ,'_ /'.-||            :       
      2016   _..-' ''/    ||  \    \   _|/|     
           \        /-._;/||   \    \,;'   \    
           ,\      /    /`||    \   //    `:`.  
         ,'  \    /-._;/  ||    : ::    ,.   . 
       ,'     \  /    /`-.||    | || ' :  `.`.)
    _,'        |;._: /|  ;||    | `|   :    `' 
  ,'   `.      /    /`-:_/||    |  |  : \                      
  `--.   )    /'-._/    /:||       |   \ \     
     /  /    /'_  /;`-./_;||__..--';    : :    
    /  (    /  -./_  _/  .||'o |   /     ' |    
   /  , \._/_/_./--''/_  /||___|_,'      | |    
  :  /   `'-'--'----'---------'          / |    
  | :     O ._O   O_. O ._O   O_.       ; ;    
  : `.      //    //    //    //       /                   
~~~`.______//____//____//____//_______ ,'~~                     
          //    //~   //    // ~ ~ ~ ~~~~                    
   ~~   _//   _//   _// ~ _//    ~  ~ ~ ~    
 ~     / /   / /   / /   / /  ~      ~~       
      ~~~   ~~~   ~~~   ~~~     
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
                                %  Setting Sail to the horizon.    %
                                %             Yours                %
                                %       lulzSecurity2016           %
                                %          % |\| |\| %             %
                                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                  
                                \   lulzfuzzer.py-{host}{port}     /
                                 \________________________________/ 
"""



#import 
import socket 
import sys  
import httplib 
import urllib 

 

# Usige the script: ./script.py <RHOST> <RPORT>

#mainconfig
RHOST = sys.argv[1]
RPORT = sys.argv[2]
 
# Define your buffer string that will be incremented until a potential crash
buffer = '\x41\x50\x49'*50

 
# Create a loop that will connect to the service and send the buffer:
while True:
  try:
    # send buffer
    # increment buffer by 50
    buffer = buffer + '\x41\x50\x49'*50
  except:
    print "Buffer Length: "+len(buffer)
    print "Can't connect to service...check debugger for potential crash"
